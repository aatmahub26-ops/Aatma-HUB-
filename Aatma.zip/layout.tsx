
"use client";

import { SidebarProvider, Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarInset, SidebarTrigger } from "@/components/ui/sidebar";
import { LayoutDashboard, Users, ShoppingCart, Settings, BellRing, ArrowLeft, ShieldAlert, CreditCard, Wallet, Loader2, ShieldCheck, Gamepad2, Gift, Briefcase, Megaphone, History, Activity, Tag } from "lucide-react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { logSecurityEvent } from "@/lib/admin-audit";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const { user, profile, loading } = useAuth();

  useEffect(() => {
    if (!loading) {
      if (!user) {
        router.push("/login");
      } else if (profile && !['admin', 'staff', 'support'].includes(profile.role || '')) {
        logSecurityEvent('UNAUTHORIZED_ADMIN_ACCESS', `User ${profile.email} attempted to access ${pathname}`);
        router.push("/dashboard");
      }
    }
  }, [user, profile, loading, router, pathname]);

  const role = profile?.role || 'user';

  const adminMenu = [
    { title: "Dashboard", icon: LayoutDashboard, url: "/admin", roles: ['admin', 'staff', 'support'] },
    { title: "Manage Orders", icon: ShoppingCart, url: "/admin/orders", roles: ['admin', 'staff', 'support'] },
    { title: "Coupons HUB", icon: Tag, url: "/admin/marketing/coupons", roles: ['admin'] },
    { title: "Marketing HUB", icon: Megaphone, url: "/admin/marketing/popup", roles: ['admin'] },
    { title: "Reseller HUB", icon: Briefcase, url: "/admin/resellers", roles: ['admin', 'staff'] },
    { title: "Audit Trail", icon: Activity, url: "/admin/audit-logs", roles: ['admin'] },
    { title: "Payments Registry", icon: CreditCard, url: "/admin/payments", roles: ['admin', 'staff'] },
    { title: "B2B Catalog", icon: Gamepad2, url: "/admin/catalog", roles: ['admin', 'staff'] },
    { title: "Affiliate Hub", icon: Gift, url: "/admin/referrals", roles: ['admin', 'staff'] },
    { title: "User Database", icon: Users, url: "/admin/users", roles: ['admin', 'staff', 'support'] },
    { title: "KYC Center", icon: ShieldCheck, url: "/admin/kyc", roles: ['admin', 'staff', 'support'] },
    { title: "Recharge Queue", icon: Wallet, url: "/admin/recharges", roles: ['admin', 'staff', 'support'] },
    { title: "System Logic", icon: Settings, url: "/admin/providers", roles: ['admin'] },
  ].filter(item => item.roles.includes(role));

  if (loading || (user && profile && !['admin', 'staff', 'support'].includes(profile.role || ''))) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
           <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
           <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground">Authenticating Admin Node...</p>
        </div>
      </div>
    );
  }

  return (
    <SidebarProvider>
      <div className="flex min-h-screen bg-background w-full text-foreground">
        <Sidebar className="border-r border-white/5">
          <SidebarContent className="bg-card">
            <div className="p-6">
              <Link href="/" className="flex items-center space-x-2">
                <div className="bg-destructive p-1 rounded-lg">
                  <ShieldAlert className="h-5 w-5 text-white" />
                </div>
                <span className="font-headline text-lg font-bold tracking-tighter text-white uppercase">
                  Admin <span className="text-destructive">Console</span>
                </span>
              </Link>
              <div className="mt-2 flex items-center gap-2">
                 <div className="h-1.5 w-1.5 rounded-full bg-green-500 animate-pulse" />
                 <span className="text-[8px] font-bold uppercase tracking-widest text-muted-foreground">{role} node active</span>
              </div>
            </div>
            <SidebarGroup>
              <SidebarGroupContent>
                <SidebarMenu>
                  {adminMenu.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton asChild isActive={pathname === item.url}>
                        <Link href={item.url} className={`flex items-center space-x-3 px-3 py-3 rounded-xl transition-all`}>
                          <item.icon className={`h-5 w-5 ${pathname === item.url ? 'text-primary' : 'text-muted-foreground'}`} />
                          <span className={`font-bold text-xs uppercase tracking-widest ${pathname === item.url ? 'text-foreground' : 'text-muted-foreground'}`}>{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
            
            <div className="mt-auto p-4 border-t border-white/5">
               <Link href="/dashboard" className="flex items-center space-x-3 px-3 py-2 text-[10px] font-bold uppercase tracking-widest text-muted-foreground hover:text-foreground transition-colors">
                 <ArrowLeft className="h-4 w-4" />
                 <span>Exit to Dashboard</span>
               </Link>
            </div>
          </SidebarContent>
        </Sidebar>
        
        <SidebarInset className="flex flex-col bg-background">
          <header className="h-16 border-b border-white/5 flex items-center px-8 justify-between bg-card/30 backdrop-blur-md sticky top-0 z-40">
            <div className="flex items-center gap-4">
              <SidebarTrigger />
              <h1 className="font-headline font-bold text-sm uppercase tracking-widest">
                Intelligence <span className="text-muted-foreground">/</span> {adminMenu.find(m => m.url === pathname)?.title || "Overview"}
              </h1>
            </div>
            <div className="flex items-center gap-4">
               <ThemeToggle />
               <Button variant="ghost" size="icon" className="relative">
                 <BellRing className="h-5 w-5" />
                 <span className="absolute top-2 right-2 h-2 w-2 bg-primary rounded-full" />
               </Button>
               <div className="h-8 w-8 rounded-xl bg-destructive flex items-center justify-center font-bold text-[10px] text-white shadow-[0_0_15px_rgba(239,68,68,0.3)]">
                  {profile?.firstName?.charAt(0)}{profile?.lastName?.charAt(0)}
               </div>
            </div>
          </header>
          <main className="p-8 overflow-y-auto">
            {children}
          </main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}
